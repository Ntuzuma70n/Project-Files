﻿using System;

namespace ClassLibrary1
{
    public class Class1
    {
        public static int session;

        public void setSession(int t)
        {
            session = t;
        }

        public int getSession()
        {
            return session;
        }
    }
}
