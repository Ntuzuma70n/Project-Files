﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace POEtask3
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        { 

    }

        protected void btn_Reg_Click(object sender, EventArgs e)
        {
            SqlConnection con = NewMethod();

            con.Close();
        }

        private SqlConnection NewMethod()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-QGMV79Q;Initial Catalog=Registerpoe;Integrated Security=True");
            con.Open();

            string query = "INSERT INTO Login (userName, Password) VALUES('" + txt_regUserName.Text + "','" + txt_regPassword.Text + "')";
            Response.Write("Succesfully Registered");

            SqlCommand sql = new SqlCommand(query, con);

            SqlDataReader sqlDataReader = sql.ExecuteReader();
            SqlDataReader read = sqlDataReader;
            return con;
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Login.aspx");
        }
    }
}