﻿using ClassLibrary1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;

namespace POEtask3
{
    public partial class Please_enter_details : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn;
                SqlDataReader dbtl;
                NewMethod(out conn, out dbtl);
                while (dbtl.Read())
                {
                    Response.Write("On" + dbtl.GetValue(1).ToString() + "you have" + dbtl.GetValue(0).ToString());
                }
                conn.Close();
            }
            catch (Exception T)// catch block to throw error message
               {

                Response.Write("Something went wrong" + "\n" + T.Message);
                }

            

               }

        private void NewMethod(out SqlConnection conn, out SqlDataReader dbtl)
        {
            conn = new SqlConnection(@"Data Source=DESKTOP-QGMV79Q;Initial Catalog=Registerpoe;Integrated Security=True");
            conn.Open();
            ClassLibrary1.Class1 obj = new ClassLibrary1.Class1();
            //display current user id 
            Response.Write("ID " + obj.getSession());
            string query = "Select mName, Date from Reminder where ID='" + obj.getSession() + "'";
            SqlCommand command = new SqlCommand(query, conn);
            dbtl = command.ExecuteReader();
        }


        protected void btn_Strore_Click(object sender, EventArgs e)
        {
            ClassLibrary1.Class1 obj = new ClassLibrary1.Class1();
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-QGMV79Q;Initial Catalog=Registerpoe;Integrated Security=True");
            string query = "INSERT INTO Modules VALUES('" + txt_moduleCode.Text + "','" + txt_moduleName.Text + "','" + txt_moduleCredits.Text + "','" + txt_hoursPerweek.Text + "','" + txt_numOfweeks.Text + "','" + txt_hoursSpent.Text + "', '" + obj.getSession() + "')";
            SqlCommand sql = new SqlCommand(query, conn);
            conn.Open();
            sql.ExecuteNonQuery();
            Response.Write("Details saved");
            conn.Close();

            txt_moduleCode.Text = "";
            txt_moduleName.Text = "";
            txt_moduleCredits.Text = "";
            txt_hoursPerweek.Text = "";
            txt_numOfweeks.Text = "";
            txt_hoursSpent.Text = "";


        }

        protected void btn_setReminder_Click(object sender, EventArgs e)
        {
            ClassLibrary1.Class1 obj = new ClassLibrary1.Class1();
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-QGMV79Q;Initial Catalog=Registerpoe;Integrated Security=True");
            string query = "INSERT INTO Reminder VALUES('" + txt_mName.Text + "','" + txt_Date.Text + "', '" + obj.getSession() + "')";
            SqlCommand sql = new SqlCommand(query, conn);
            conn.Open();
            sql.ExecuteNonQuery();
            Response.Write("Data stored ");

            txt_mName.Text = "";
            txt_Date.Text = "";


            conn.Close();

        }

        protected void btn_LogOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Login.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-QGMV79Q;Initial Catalog=Registerpoe;Integrated Security=True");
                conn.Open();
                ClassLibrary1.Class1 obj = new ClassLibrary1.Class1();
                SqlDataAdapter sqlde = new SqlDataAdapter("select * from modules where ID=" + obj.getSession(), conn);
                DataTable drtl = new DataTable();
                sqlde.Fill(drtl);
                GridView1.DataSource = drtl;
                GridView1.DataBind();

            }
            catch (Exception T)
            {

                Response.Write("OOPS Something went wrong");
            }
        }
    }
}