﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace POEtask3
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
       
    }

        protected void btn_Login_Click1(object sender, EventArgs e)
        {
            ClassLibrary1.Class1 obj = new ClassLibrary1.Class1();


            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-QGMV79Q;Initial Catalog=Registerpoe;Integrated Security=True");


            string query1 = "Select* from Login where userName='" + txt_userName.Text.Trim() + "'and Password= '" + txt_password.Text.Trim() + "'";
            con.Open();
            SqlCommand Command = new SqlCommand(query1, con);
            SqlDataReader dtbl = Command.ExecuteReader();

        

            bool check = false;

             while (dtbl.Read())
            {
               if (dtbl.GetValue(1).ToString().Equals(txt_userName.Text))
               {
                 check = true;
            
                obj.setSession(Convert.ToInt32(dtbl.GetValue(0)));
            

                 }
               }
             if (check = true)
             {
                  Response.Write("Details need to be captured");
               Response.Redirect("~/Please enter details.aspx");
             }
              else
              {
                 Response.Write("Inaccurate details");
              }
            con.Close();
        }

        protected void btn_newReg_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Registration.aspx");
        }
    }
    }
