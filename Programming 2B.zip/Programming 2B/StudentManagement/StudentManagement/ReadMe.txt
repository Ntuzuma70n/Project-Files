#**Time managemant App**

###**DESCRIPTION**
This is an applicancation that is design to help on manage their time during the hectic semester of their academic years.
The web application will be able to calculate the amount of hours a student needs to spend studying on a specific module 
in order to help them manage their time correctly.

###**VISUAL STUDIO**
This App can run on any vof the following visual studio versions:

*Visual Studio 2022	Dev17	2021-11-08[59]	17.0	
*Visual Studio 2019	Dev16	2019-04-02[62]	16.0	
*Visual Studio 2017	Dev15	2017-03-07[67]	15.0

###**EXTRACTION**
1.Unzip the the folder StudentManagement.Zip usinng ZIP Or 7Z
2.Open the Unziped folder and  click file named StudentManagement.sln

###**HOW TO USE THE APP**
1.run microsoft sql management studio.
2.Load the SQLQuery1 file to microsoft sql management studio.
3. Open and run the app with Visual Studio.
4.open solution explorer in visual studio to get list of folders and file.
5.Locate Appsetting.json open it and change connection string 
"Data Source=DESKTOP-2JT1GK3;Initial Catalog=Users;Integrated Security=True" to the one in you ms management
6. Run the web application and have Fun.
7. close the app and run it again if you wish to try again.



### AUTHORS AND ACKNOWLEDGE
This code is written by Ndivhuwo Junior Makhubele Rosebank College Studen; Student number ST10103678

###**PROJECT STATUS**
This project is complete and does not need any volunteer

###**LICENSE**
 This code is not for open source. It is copyrighted © Nduvhuwo Junioe Makhubele 2020/12/01.