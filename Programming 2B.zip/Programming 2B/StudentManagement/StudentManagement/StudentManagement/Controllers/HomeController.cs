﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using StudentManagement.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace StudentManagement.Controllers
{
    public class HomeController : Controller
    {

        List<DisplayModel> Details = new List<DisplayModel>();

        private readonly IConfiguration configuration;

        public HomeController(IConfiguration config)
        {
            this.configuration = config;

        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterModel user)
        {
            SqlCommand cmd;
            string connectionstring = configuration.GetConnectionString("constr");
            SqlConnection conn = new SqlConnection(connectionstring);

            if (ModelState.IsValid)
            {
                try
                {
                    conn.Open();//open connection
                    string query = "INSERT INTO Students (Username,User_Password) VALUES ('" + user.ConfirmUsername + "','" + user.ConfirmPassword + "')";
                    cmd = new SqlCommand(query, conn);//using the command 

                    cmd.ExecuteNonQuery();
                    conn.Close();//Close connection

                }
                catch (Exception)
                {
                    throw;
                }
                return RedirectToAction("Login");
            }
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginModel user)
        {
            SqlCommand cmd;
            string connectionstring = configuration.GetConnectionString("constr");
            SqlConnection conn = new SqlConnection(connectionstring);

            if (ModelState.IsValid)
            {
                try
                {
                    conn.Open();//open connection
                    string query = "SELECT * from Students where Username='" + user.Username + "'and User_Password='" + user.Password + "'";
                    cmd = new SqlCommand(query, conn);//using the command 
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();

                    int count = 0;

                    while (dr.Read())
                    {
                        count++;
                    }
                    conn.Close();//Close connection

                    if (count == 1)
                    {
                        manage.LogedInUser = user.Username;
                        return RedirectToAction("LoadModules");
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return View();
        }

        public IActionResult LoadModules()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult LoadModules(ModulesModel Moduledata)
        {
            if (ModelState.IsValid)
            {
                int count = 0;
                Array.Resize(ref manage.moduleCode, manage.moduleCode.Length + 1);
                Array.Resize(ref manage.moduleName, manage.moduleName.Length + 1);
                Array.Resize(ref manage.Credit, manage.Credit.Length + 1);
                Array.Resize(ref manage.hoursPerWeek, manage.hoursPerWeek.Length + 1);

                try
                {
                    manage.moduleCode[count] = Moduledata.ModuleCode;
                    manage.moduleName[count] = Moduledata.ModuleName;
                    manage.Credit[count] = Moduledata.Credits;
                    manage.hoursPerWeek[count] = Moduledata.ClassHour;

                    count++;//increment count
                }
                catch (Exception)
                {
                    throw;
                }
                return RedirectToAction("LoadModules");
            }
            return View();
        }

        public IActionResult Semester()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Semester(SemesterModel data)
        {
            SqlCommand cmd;
            string connectionstring = configuration.GetConnectionString("constr");
            SqlConnection conn = new SqlConnection(connectionstring);
            if (ModelState.IsValid)
            {
                manage.numOfWeeks = data.Weeks;
                manage.startSemester = data.StartDate;
                manage.endSemester = manage.startSemester.AddDays(manage.numOfWeeks * 7);


                try
                {

                    Array.Resize(ref manage.array, manage.array.Length + manage.Credit.Length);//Resizing array of objects
                    Array.Resize(ref manage.selfstudy, manage.selfstudy.Length + manage.Credit.Length);//Resizing array of objects

                    for (int i = 0; i < manage.array.Length; i++)
                    {
                        manage.selfstudy[i] = ((manage.Credit[i] * 10) / manage.numOfWeeks) - manage.hoursPerWeek[i];//calculating left-study and populating its array
                        manage.array[i] = manage.moduleCode[i] + "\t\t" + manage.moduleName[i] + "\t" + manage.Credit[i] + "\t\t" + manage.hoursPerWeek[i] + "\t\t" + manage.selfstudy[i] + "\n";
                        string query = string.Format("INSERT INTO Students_Modules VALUES('{0}','{1}','{2}',{3},{4},{5})", manage.LogedInUser, manage.moduleCode[i], manage.moduleName[i], manage.Credit[i], manage.hoursPerWeek[i], manage.selfstudy[i]);
                        cmd = new SqlCommand(query, conn);//using the command 
                        conn.Open();//open connection
                        cmd.ExecuteNonQuery();
                        conn.Close();//open connection
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                return RedirectToAction("LoadModules");
            }
            return View();
        }
        public IActionResult WorkedHours()
        {
            return View();
        }
        public IActionResult FileName()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult WorkedHours(WorkedHoursModel hr)
        {
            SqlCommand cmd;
            string connectionstring = configuration.GetConnectionString("constr");
            SqlConnection conn = new SqlConnection(connectionstring);
            if (ModelState.IsValid)
            {
                try
                {
                    manage.moduleNameSearch = hr.SearchModuleName;
                    manage.hoursSpent = hr.HoursSpent;
                    manage.date_of_work_done = hr.DateWorkDone;

                    conn.Open();//open connection
                    string query = "SELECT * FROM Students_Modules where Module_Name='" + hr.SearchModuleName + "'and Username='" + manage.LogedInUser + "'";
                    cmd = new SqlCommand(query, conn);//using the command 
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr = cmd.ExecuteReader();

                    int count = 0;

                    while (dr.Read())
                    {
                        count++;//increment count
                    }
                    conn.Close();//Close connection

                    if (count == 1)
                    {
                        string query1 = "UPDATE Students_Modules SET Self_Study=Self_Study-'" + manage.hoursSpent + "'where Username='" + manage.LogedInUser + "'and Module_Name='" + manage.moduleNameSearch + "'";
                        cmd = new SqlCommand(query1, conn);
                        conn.Open();//open connection
                        cmd.ExecuteNonQuery();
                        conn.Close();//open connection
                    }
                }
                catch (Exception)
                {
                    // MessageBox.Show("You have enetred incorrect value");
                }
                return RedirectToAction("WorkedHours");
            }
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Display()
        {
            FetchData();
            return View(Details);
        }

        private void FetchData()
        {
            SqlCommand cmd;
            string connectionstring = configuration.GetConnectionString("constr");
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                conn.Open();

                string query = "SELECT [Username],[Module_Code],[Module_Name],[Credits],[Class_Hrs_Weekly],[Self_Study] FROM [Students_Modules] where [Username]='" + manage.LogedInUser + "'";
                cmd = new SqlCommand(query, conn);//using the command 
               SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Details.Add(new DisplayModel() { User=dr["Username"].ToString() 
                    ,ModuleCode=dr["Module_Code"].ToString()
                    ,ModuleName = dr["Module_Name"].ToString()
                    ,Credit = dr["Credits"].ToString()
                    ,Hours_Per_Week = dr["Class_Hrs_Weekly"].ToString()
                    ,Self_Study = dr["Self_Study"].ToString()
                    });
                }
                conn.Close();
        }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
