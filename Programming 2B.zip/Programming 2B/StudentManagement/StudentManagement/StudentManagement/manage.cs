﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagement
{
    public class manage
    {
        //Declaring variable
        public static string[] moduleCode = new string[0];
        public static string[] moduleName = new string[0];
        public static int[] Credit = new int[0];
        public static int[] hoursPerWeek = new int[0];
        public static int[] selfstudy = new int[0];
        public static object[] array = new object[0];//Declaring object array
        public static int numOfWeeks;
        public static DateTime date;
        public static DateTime date_of_work_done;

        public static string moduleNameSearch;
        public static int hoursSpent;


        public static string LogedInUser;
        //public static string moduleCode;
        //public static string moduleName;
        //public static int credits;
        //public static int classHours;


        // public static int numOfWeeks;
        public static DateTime startSemester;
        public static DateTime endSemester;
        //public static DateTime date_of_work_done;
    }
}
