﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Models
{
    public class SemesterModel
    {
        [Display(Name = "Number of weeks of semester")]
        [Required(ErrorMessage = "Your need to enter number of weeks of semester")]
        public int Weeks { get; set; }

        [Display(Name = "Start date of semester")]
        [Required(ErrorMessage = "Your need to enter start date of semester")]
        public DateTime StartDate { get; set; }
    }
}
