﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagement.Models
{
    public class DisplayModel
    {
        public string User { get; set; }
        public string ModuleCode { get; set; }
        public string ModuleName { get; set; }
        public string Credit { get; set; }
        public string Hours_Per_Week { get; set; }
        public string Self_Study { get; set; }

    }
}
