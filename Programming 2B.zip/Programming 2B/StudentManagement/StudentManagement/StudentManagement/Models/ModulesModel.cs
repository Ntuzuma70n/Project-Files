﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Models
{
    public class ModulesModel
    {
        [Display (Name ="Module Code")]
        [Required(ErrorMessage ="Your need to enter module code")]
        public string ModuleCode { get; set; }

        [Display(Name = "Module Name")]
        [Required(ErrorMessage = "Your need to enter module name")]
        public string ModuleName { get; set; }

        [Display(Name = "Module Credit")]
        [Required(ErrorMessage = "Your need to enter credit")]
        public int    Credits { get; set; }

        [Display(Name = "class per hour")]
        [Required(ErrorMessage = "Your need to enter class per hour")]
        public int    ClassHour { get; set; }

    }
}
