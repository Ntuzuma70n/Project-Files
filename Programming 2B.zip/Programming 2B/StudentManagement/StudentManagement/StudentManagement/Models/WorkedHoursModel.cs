﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Models
{
    public class WorkedHoursModel
    {
        [Display(Name = "Date worked on")]
        [Required(ErrorMessage = "Your need to enter date you worked on")]
        public DateTime DateWorkDone { get; set; }

        [Display(Name = "Search Module Name")]
        [Required(ErrorMessage = "Your need to Module Name you wish to edit")]
        public string SearchModuleName { get; set; }

        [Display(Name = "Number of Hours spent")]
        [Required(ErrorMessage = "Your need to enter Hours spent")]
        public int HoursSpent { get; set; }
    }
}
