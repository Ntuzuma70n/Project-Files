﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagement.Models
{
    public class RegisterModel
    {

        [Display(Name = "Username")]
        [Required(ErrorMessage = "You need to enter your username")]
        public string RegisterUsername { get; set; }

        [Display(Name = "Confirm Username")]
        [Compare("RegisterUsername", ErrorMessage = "The Username and the Confirm Username must match")]
        public string ConfirmUsername { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "You need to enter your password")]
        [DataType(DataType.Password)]
        [StringLength(100, MinimumLength = 10, ErrorMessage = "You need to provide a long")]
        public string RegisterPassword { get; set; }

        [Display(Name = "Confirm Password")]
        [Compare("RegisterPassword", ErrorMessage = "The Password and the Confirm Password must match")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }

    }
}
