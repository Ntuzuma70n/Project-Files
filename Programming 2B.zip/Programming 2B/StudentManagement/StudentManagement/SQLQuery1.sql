
Create Database Users;

Use Users;

CREATE TABLE Students(Username varchar(50) NOT NULL, 
User_Password varchar(40) NOT NULL, PRIMARY KEY(Username));

CREATE TABLE Students_Modules(Username varchar(50) NOT NULL FOREIGN KEY REFERENCES Students(Username),
Module_Code CHAR(8) NOT NULL, 
Module_Name varchar(40) NOT NULL,
Credits int NOT NULL,
Class_Hrs_Weekly int NOT NULL,
Self_Study int NOT NULL,
PRIMARY KEY (Module_Code));

Select * From Students_Modules;
Select * From Students;

